<?php
/**
 * Module Social Media Order
 * PrestaShop 1.7.x
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class SocialMediaOrder extends Module
{
    const ORDER_STATUS_NAME = 'Commande rapide';

    public function __construct()
    {
        $this->name          = 'socialmediaorder';
        $this->tab           = 'front_office_features';
        $this->version       = '1.0.0';
        $this->author        = 'Dev';
        $this->need_instance = 0;
        $this->bootstrap     = true;
        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);

        parent::__construct();

        $this->displayName = $this->l('Commande rapide');
        $this->description = $this->l('Formulaire de commande rapide sur la page produit.');
    }

    public function install()
    {
        if (!parent::install()) {
            return false;
        }

        $this->createOrderStatus();
        $this->createTable();

        $hooks = array(
            'displayHeader',
            'displayFooter',
            'displayProductButtons',
            'displayProductAdditionalInfo',
            'displayProductFooter',
            'actionFrontControllerSetMedia',
            'displaySocialMediaOrderForm',
        );

        foreach ($hooks as $hook) {
            $this->registerHook($hook);
        }

        return true;
    }

    public function uninstall()
    {
        $id_status = (int) Configuration::get('SOCIALMEDIAORDER_STATUS_ID');
        if ($id_status) {
            $state = new OrderState($id_status);
            $state->delete();
            Configuration::deleteByName('SOCIALMEDIAORDER_STATUS_ID');
        }
        Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'socialmediaorder_lead`');
        return parent::uninstall();
    }

    private function createOrderStatus()
    {
        $id_existing = (int) Configuration::get('SOCIALMEDIAORDER_STATUS_ID');
        if ($id_existing && Validate::isLoadedObject(new OrderState($id_existing))) {
            return true;
        }

        $state = new OrderState();
        $state->name = array();
        foreach (Language::getLanguages() as $lang) {
            $state->name[$lang['id_lang']] = self::ORDER_STATUS_NAME;
        }
        $state->color        = '#e74c3c';
        $state->logable      = true;
        $state->invoice      = false;
        $state->hidden       = false;
        $state->send_email   = false;
        $state->module_name  = $this->name;
        $state->unremovable  = false;
        $state->delivery     = false;
        $state->shipped      = false;
        $state->paid         = false;
        $state->pdf_delivery = false;
        $state->pdf_invoice  = false;
        $state->deleted      = false;

        if ($state->add()) {
            Configuration::updateValue('SOCIALMEDIAORDER_STATUS_ID', $state->id);
        }
        return true;
    }

    private function createTable()
    {
        return Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'socialmediaorder_lead` (
                `id_lead`    INT(11)      NOT NULL AUTO_INCREMENT,
                `id_product` INT(11)      NOT NULL,
                `id_order`   INT(11)      DEFAULT NULL,
                `fullname`   VARCHAR(255) NOT NULL,
                `phone`      VARCHAR(30)  NOT NULL,
                `address`    TEXT         NOT NULL,
                `date_add`   DATETIME     NOT NULL,
                PRIMARY KEY (`id_lead`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8
        ');
    }

    public function hookActionFrontControllerSetMedia($params)
    {
        if ($this->context->controller->php_self === 'product') {
            $this->context->controller->addCSS($this->_path . 'views/css/socialmediaorder.css');
        }
    }

    public function hookDisplayHeader($params)
    {
        if ($this->context->controller->php_self === 'product') {
            $this->context->controller->addCSS($this->_path . 'views/css/socialmediaorder.css');
        }
    }

    public function hookDisplayProductButtons($params)
    {
        return $this->renderForm($params);
    }

    public function hookDisplayProductAdditionalInfo($params)
    {
        return $this->renderForm($params);
    }

    public function hookDisplayProductFooter($params)
    {
        return $this->renderForm($params);
    }

    public function hookDisplaySocialMediaOrderForm($params)
    {
        return $this->renderForm($params);
    }

    public function hookDisplayFooter($params)
    {
        if ($this->context->controller->php_self !== 'product') {
            return '';
        }

        $id_product = (int) Tools::getValue('id_product');
        if (!$id_product) {
            return '';
        }

        $action_url = $this->context->link->getModuleLink($this->name, 'submit', array(), true);
        $form_html  = $this->buildFormHtml($id_product, $action_url);
        $escaped    = json_encode($form_html);

        return '
<script>
(function() {
    function smoInject() {
        if (document.getElementById("smo-wrapper-' . $id_product . '")) { return; }
        var html = ' . $escaped . ';
        var div = document.createElement("div");
        div.innerHTML = html;
        var targets = [
            ".elementor-widget-product-add-to-cart",
            "[data-widget_type=\'product-add-to-cart.default\']",
            ".product-actions",
            "#add-to-cart-or-refresh",
            ".product-information",
            "#main"
        ];
        var inserted = false;
        for (var i = 0; i < targets.length; i++) {
            var el = document.querySelector(targets[i]);
            if (el) {
                el.parentNode.insertBefore(div, el.nextSibling);
                inserted = true;
                break;
            }
        }
        if (!inserted) {
            var main = document.getElementById("main");
            if (main) { main.appendChild(div); }
        }
        smoBindButton(' . $id_product . ');
    }

    function smoBindButton(pid) {
        var btn = document.querySelector(".smo-btn-submit[data-product=\"" + pid + "\"]");
        if (!btn || btn._smoReady) { return; }
        btn._smoReady = true;
        btn.addEventListener("click", function() {
            var url      = btn.getAttribute("data-url");
            var fullname = document.getElementById("smo_fullname_" + pid).value.trim();
            var phone    = document.getElementById("smo_phone_" + pid).value.trim();
            var address  = document.getElementById("smo_address_" + pid).value.trim();
            var email    = document.getElementById("smo_email_" + pid).value.trim();
            var alertBox = document.getElementById("smo-alert-" + pid);
            var errors   = [];
            if (!fullname) { errors.push("Nom et Pr\u00e9nom est obligatoire."); }
            if (!phone)    { errors.push("Num\u00e9ro de t\u00e9l\u00e9phone est obligatoire."); }
            if (!address)  { errors.push("Adresse est obligatoire."); }
            
            if (errors.length) {
                alertBox.innerHTML = "<div class=\"smo-alert smo-error\">\u26a0\ufe0f " + errors.join("<br>") + "</div>";
                return;
            }
            btn.disabled = true;
            btn.innerHTML = "\u23f3 Envoi en cours...";
            alertBox.innerHTML = "";
            var fd = new FormData();
            fd.append("smo_product_id", pid);
            fd.append("smo_fullname",   fullname);
            fd.append("smo_phone",      phone);
            fd.append("smo_address",    address);
            fd.append("smo_email",       email);
            fd.append("smo_submit",     "1");
            fd.append("smo_ajax",       "1");
            fetch(url, { method: "POST", body: fd })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.success) {
                        alertBox.innerHTML = "<div class=\"smo-alert smo-success\">\u2705 Commande enregistr\u00e9e\u00a0! Nous vous contacterons tr\u00e8s bient\u00f4t.</div>";
                        document.getElementById("smo_fullname_" + pid).value = "";
                        document.getElementById("smo_phone_" + pid).value    = "";
                        document.getElementById("smo_address_" + pid).value  = "";
                        document.getElementById("smo_email_" + pid).value     = "";
                    } else {
                        alertBox.innerHTML = "<div class=\"smo-alert smo-error\">\u26a0\ufe0f " + (data.error || "Erreur inconnue.") + "</div>";
                    }
                    btn.innerHTML = "<span class=\"smo-btn-icon\">\u2713<\/span> Valider ma commande";
                    btn.disabled  = false;
                })
                .catch(function() {
                    alertBox.innerHTML = "<div class=\"smo-alert smo-error\">\u26a0\ufe0f Erreur de connexion.<\/div>";
                    btn.innerHTML = "<span class=\"smo-btn-icon\">\u2713<\/span> Valider ma commande";
                    btn.disabled  = false;
                });
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", smoInject);
    } else {
        smoInject();
    }
})();
</script>';
    }

    private function renderForm($params)
    {
        $product = isset($params['product']) ? $params['product'] : null;
        if ($product) {
            $id_product = (int) (is_array($product) ? $product['id_product'] : $product->id);
        } else {
            $id_product = (int) Tools::getValue('id_product');
        }
        if (!$id_product) {
            return '';
        }
        $action_url = $this->context->link->getModuleLink($this->name, 'submit', array(), true);
        $html = $this->buildFormHtml($id_product, $action_url);
        $this->context->controller->addCSS($this->_path . 'views/css/socialmediaorder.css');
        return $html;
    }

    private function buildFormHtml($id_product, $action_url)
    {
        $id  = (int) $id_product;
        $url = htmlspecialchars($action_url, ENT_QUOTES, 'UTF-8');

        return '
<div class="smo-wrapper" id="smo-wrapper-' . $id . '">
    <div class="smo-header">
        <span class="smo-icon">&#128242;</span>
        <span class="smo-title">Commandez Vite !</span>
    </div>
    <div id="smo-alert-' . $id . '"></div>
    <div class="smo-form">
        <div class="smo-field">
            <label for="smo_fullname_' . $id . '">Nom et Pr&eacute;nom <span class="smo-required">*</span></label>
            <input type="text" id="smo_fullname_' . $id . '" class="smo-input" placeholder="Ex: Ahmed Ben Salah" maxlength="255">
        </div>
        <div class="smo-field">
            <label for="smo_phone_' . $id . '">Num&eacute;ro de t&eacute;l&eacute;phone <span class="smo-required">*</span></label>
            <input type="tel" id="smo_phone_' . $id . '" class="smo-input" placeholder="Ex: +216 XX XXX XXX" maxlength="30">
        </div>
        <div class="smo-field">
            <label for="smo_address_' . $id . '">Adresse de livraison <span class="smo-required">*</span></label>
            <textarea id="smo_address_' . $id . '" class="smo-input" placeholder="Ex: Rue 10, Cit&eacute; des fleurs" rows="3" maxlength="500"></textarea>
        </div>
        <div class="smo-field">
            <label for="smo_email_' . $id . '">Email <span class="smo-required">*</span></label>
            <input type="email" id="smo_email_' . $id . '" class="smo-input" placeholder="Ex: ahmed@gmail.com" maxlength="150">
        </div>
        <button type="button" class="smo-btn-submit" data-product="' . $id . '" data-url="' . $url . '" onclick="smoHandleSubmit_' . $id . '(this)">
            <span class="smo-btn-icon">&#10003;</span> Valider ma commande
        </button>
        <p class="smo-note">Notre &eacute;quipe vous contactera pour confirmer votre commande.</p>
    </div>
</div>
<script>
function smoHandleSubmit_' . $id . '(btn) {
    var pid      = "' . $id . '";
    var url      = btn.getAttribute("data-url");
    var fullname = document.getElementById("smo_fullname_" + pid).value.trim();
    var phone    = document.getElementById("smo_phone_"    + pid).value.trim();
    var address  = document.getElementById("smo_address_"  + pid).value.trim();
    var email    = document.getElementById("smo_email_"     + pid).value.trim();
    var alertBox = document.getElementById("smo-alert-"    + pid);
    var errors   = [];
    if (!fullname) errors.push("Nom et Pr\u00e9nom est obligatoire.");
    if (!phone)    errors.push("Num\u00e9ro de t\u00e9l\u00e9phone est obligatoire.");
    if (!address)  errors.push("Adresse est obligatoire.");
    
    if (errors.length) {
        alertBox.innerHTML = "<div class=\"smo-alert smo-error\">\u26a0 " + errors.join("<br>") + "</div>";
        return;
    }
    btn.disabled = true;
    btn.innerHTML = "\u23f3 Envoi en cours...";
    alertBox.innerHTML = "";
    var fd = new FormData();
    fd.append("smo_product_id", pid);
    fd.append("smo_fullname",   fullname);
    fd.append("smo_phone",      phone);
    fd.append("smo_address",    address);
    fd.append("smo_email",       email);
    fd.append("smo_submit",     "1");
    fd.append("smo_ajax",       "1");
    fetch(url, { method: "POST", body: fd })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.success) {
                alertBox.innerHTML = "<div class=\"smo-alert smo-success\">\u2705 Commande enregistr\u00e9e ! Nous vous contacterons tr\u00e8s bient\u00f4t.</div>";
                document.getElementById("smo_fullname_" + pid).value = "";
                document.getElementById("smo_phone_"    + pid).value = "";
                document.getElementById("smo_address_"  + pid).value = "";
                document.getElementById("smo_email_"     + pid).value = "";
            } else {
                alertBox.innerHTML = "<div class=\"smo-alert smo-error\">\u26a0 " + (data.error || "Erreur inconnue.") + "</div>";
            }
            btn.innerHTML = "<span class=\"smo-btn-icon\">\u2713<\/span> Valider ma commande";
            btn.disabled  = false;
        })
        .catch(function() {
            alertBox.innerHTML = "<div class=\"smo-alert smo-error\">\u26a0 Erreur de connexion.<\/div>";
            btn.innerHTML = "<span class=\"smo-btn-icon\">\u2713<\/span> Valider ma commande";
            btn.disabled  = false;
        });
}
</script>';
    }

    public function getContent()
    {
        $id_status = (int) Configuration::get('SOCIALMEDIAORDER_STATUS_ID');
        return '<div class="panel">
            <h3>Social Media Order</h3>
            <p>Statut : <strong>' . self::ORDER_STATUS_NAME . '</strong> (ID: ' . $id_status . ')</p>
            <p>Les commandes apparaissent dans <strong>Commandes &rarr; Commandes</strong>.</p>
        </div>';
    }
}
