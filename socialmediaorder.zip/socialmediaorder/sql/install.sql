CREATE TABLE IF NOT EXISTS `PREFIX_socialmediaorder_lead` (
    `id_lead`       INT(11)      NOT NULL AUTO_INCREMENT,
    `id_product`    INT(11)      NOT NULL,
    `id_order`      INT(11)      DEFAULT NULL,
    `fullname`      VARCHAR(255) NOT NULL,
    `phone`         VARCHAR(30)  NOT NULL,
    `address`       TEXT         NOT NULL,
    `date_add`      DATETIME     NOT NULL,
    PRIMARY KEY (`id_lead`),
    KEY `id_product` (`id_product`),
    KEY `id_order` (`id_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
