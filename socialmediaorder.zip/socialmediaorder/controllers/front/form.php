<?php
/**
 * Controller front : retourne le HTML du formulaire
 * Utilisable depuis Elementor HTML widget ou n'importe quel template
 *
 * Usage :
 *   {hook h='displaySocialMediaOrderForm'}
 *
 *   ou via fetch :
 *   fetch('/module/socialmediaorder/form?id_product=XX')
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class SocialMediaOrderFormModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $id_product = (int) Tools::getValue('id_product');

        // Si pas dans l'URL, essayer de le récupérer depuis le contexte
        if (!$id_product) {
            $id_product = (int) Tools::getValue('id_product');
        }

        header('Content-Type: text/html; charset=utf-8');

        // Charger le CSS
        $css_url = $this->module->getPathUri() . 'views/css/socialmediaorder.css';

        $action_url = $this->context->link->getModuleLink(
            'socialmediaorder', 'submit', [], true
        );

        $id = $id_product;
        $url = htmlspecialchars($action_url, ENT_QUOTES, 'UTF-8');

        echo '<link rel="stylesheet" href="' . $css_url . '">';
        echo $this->buildFormHtml($id, $url);
        exit;
    }

    private function buildFormHtml($id, $url)
    {
        return '
<div class="smo-wrapper" id="smo-wrapper-' . $id . '">
    <div class="smo-header">
        <span class="smo-icon">&#128242;</span>
        <span class="smo-title">Commandez Vite !</span>
    </div>
    <div id="smo-alert-' . $id . '"></div>
    <div class="smo-form">
        <div class="smo-field">
            <label for="smo_fullname_' . $id . '">Nom et Pr&eacute;nom <span class="smo-required">*</span></label>
            <input type="text" id="smo_fullname_' . $id . '" class="smo-input" placeholder="Ex: Ahmed Ben Salah" maxlength="255">
        </div>
        <div class="smo-field">
            <label for="smo_phone_' . $id . '">Num&eacute;ro de t&eacute;l&eacute;phone <span class="smo-required">*</span></label>
            <input type="tel" id="smo_phone_' . $id . '" class="smo-input" placeholder="Ex: +216 XX XXX XXX" maxlength="30">
        </div>
        <div class="smo-field">
            <label for="smo_address_' . $id . '">Adresse de livraison <span class="smo-required">*</span></label>
            <textarea id="smo_address_' . $id . '" class="smo-input" placeholder="Ex: Rue 10, Cit&eacute; des fleurs" rows="3" maxlength="500"></textarea>
        </div>
        <div class="smo-field">
            <label for="smo_email_' . $id . '">Email <span class="smo-required">*</span></label>
            <input type="email" id="smo_email_' . $id . '" class="smo-input" placeholder="Ex: ahmed@gmail.com" maxlength="150">
        </div>
        <button type="button" class="smo-btn-submit" onclick="smoHandleSubmit_' . $id . '(this)" data-product="' . $id . '" data-url="' . $url . '">
            <span class="smo-btn-icon">&#10003;</span> Valider ma commande
        </button>
        <p class="smo-note">Notre &eacute;quipe vous contactera pour confirmer votre commande.</p>
    </div>
</div>
<script>
function smoHandleSubmit_' . $id . '(btn) {
    var pid      = btn.getAttribute("data-product");
    var url      = btn.getAttribute("data-url");
    var fullname = document.getElementById("smo_fullname_" + pid).value.trim();
    var phone    = document.getElementById("smo_phone_"    + pid).value.trim();
    var address  = document.getElementById("smo_address_"  + pid).value.trim();
    var email    = document.getElementById("smo_email_"    + pid).value.trim();
    var alertBox = document.getElementById("smo-alert-"    + pid);
    var errors   = [];
    if (!fullname) errors.push("Nom et Pr\u00e9nom est obligatoire.");
    if (!phone)    errors.push("Num\u00e9ro de t\u00e9l\u00e9phone est obligatoire.");
    if (!address)  errors.push("Adresse est obligatoire.");
    if (errors.length) {
        alertBox.innerHTML = "<div class=\"smo-alert smo-error\">\u26a0 " + errors.join("<br>") + "</div>";
        return;
    }
    btn.disabled = true;
    btn.innerHTML = "\u23f3 Envoi en cours...";
    alertBox.innerHTML = "";
    var fd = new FormData();
    fd.append("smo_product_id", pid);
    fd.append("smo_fullname",   fullname);
    fd.append("smo_phone",      phone);
    fd.append("smo_address",    address);
    fd.append("smo_email",      email);
    fd.append("smo_submit",     "1");
    fd.append("smo_ajax",       "1");
    fetch(url, { method: "POST", body: fd })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.success) {
                alertBox.innerHTML = "<div class=\"smo-alert smo-success\">\u2705 Commande enregistr\u00e9e\u00a0! Nous vous contacterons tr\u00e8s bient\u00f4t.</div>";
                document.getElementById("smo_fullname_" + pid).value = "";
                document.getElementById("smo_phone_"    + pid).value = "";
                document.getElementById("smo_address_"  + pid).value = "";
                document.getElementById("smo_email_"    + pid).value = "";
            } else {
                alertBox.innerHTML = "<div class=\"smo-alert smo-error\">\u26a0 " + (data.error || "Erreur inconnue.") + "</div>";
            }
            btn.innerHTML = "<span class=\"smo-btn-icon\">\u2713<\/span> Valider ma commande";
            btn.disabled  = false;
        })
        .catch(function() {
            alertBox.innerHTML = "<div class=\"smo-alert smo-error\">\u26a0 Erreur de connexion.<\/div>";
            btn.innerHTML = "<span class=\"smo-btn-icon\">\u2713<\/span> Valider ma commande";
            btn.disabled  = false;
        });
}
</script>';
    }
}
