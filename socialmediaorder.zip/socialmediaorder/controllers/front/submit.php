<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class SocialMediaOrderSubmitModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $is_ajax = (bool) Tools::getValue('smo_ajax');

        if (!Tools::isSubmit('smo_submit')) {
            if ($is_ajax) $this->jsonResponse(false, 'Requête invalide.');
            Tools::redirect('index.php');
        }

        $id_product = (int) Tools::getValue('smo_product_id');
        $fullname   = trim(Tools::getValue('smo_fullname'));
        $phone      = trim(Tools::getValue('smo_phone'));
        $address    = trim(Tools::getValue('smo_address'));
        $email      = trim(Tools::getValue('smo_email'));

        // Email par défaut si vide
        if (empty($email)) {
            $email = 'smo_' . preg_replace('/\D/', '', $phone) . '@socialmedia.local';
        }

        $errors = [];
        if (empty($fullname)) $errors[] = 'Nom et Prénom est obligatoire.';
        if (empty($phone))    $errors[] = 'Numéro de téléphone est obligatoire.';
        if (empty($address))  $errors[] = 'Adresse est obligatoire.';
        if (!$id_product)     $errors[] = 'Produit invalide.';

        if (!empty($errors)) {
            if ($is_ajax) $this->jsonResponse(false, implode(' | ', $errors));
            $this->redirectToProduct($id_product, ['smo_error' => urlencode(implode('|', $errors))]);
            return;
        }

        try {
            $id_customer = $this->getOrCreateCustomer($fullname, $phone, $email);
            $id_address  = $this->createAddress($id_customer, $fullname, $phone, $address);
            $id_order    = $this->createOrderViaValidate($id_customer, $id_address, $id_product);

            if (!$id_order) throw new Exception('Erreur création commande.');

            // Sauvegarder le lead
            Db::getInstance()->insert('socialmediaorder_lead', [
                'id_product' => (int) $id_product,
                'id_order'   => (int) $id_order,
                'fullname'   => pSQL($fullname),
                'phone'      => pSQL($phone),
                'address'    => pSQL($address),
                'date_add'   => date('Y-m-d H:i:s'),
            ]);

            if ($is_ajax) $this->jsonResponse(true);
            $this->redirectToProduct($id_product, ['smo_success' => 1]);

        } catch (Exception $e) {
            if ($is_ajax) $this->jsonResponse(false, $e->getMessage());
            $this->redirectToProduct($id_product, ['smo_error' => urlencode($e->getMessage())]);
        }
    }

    /* ------------------------------------------------------------------ */

    private function jsonResponse($success, $error = '')
    {
        header('Content-Type: application/json; charset=utf-8');
        die(json_encode(['success' => (bool)$success, 'error' => $error]));
    }

    private function redirectToProduct($id_product, $params = [])
    {
        $product = new Product((int)$id_product, false, $this->context->language->id);
        if (!Validate::isLoadedObject($product)) {
            Tools::redirect($this->context->link->getPageLink('index'));
        }
        $url = $this->context->link->getProductLink($product);
        if (!empty($params)) {
            $url .= (strpos($url, '?') !== false ? '&' : '?') . http_build_query($params);
        }
        Tools::redirect($url);
    }

    private function getOrCreateCustomer($fullname, $phone, $email)
    {
        $id = (int) Customer::customerExists($email, true, false);
        if ($id) return $id;

        $parts = explode(' ', $fullname, 2);
        $c = new Customer();
        $c->firstname  = Tools::substr($parts[0] ?? 'Client', 0, 255);
        $c->lastname   = Tools::substr($parts[1] ?? 'SocialMedia', 0, 255);
        $c->email      = $email;
        $c->passwd     = Tools::encrypt(Tools::passwdGen(16));
        $c->id_default_group = (int) Configuration::get('PS_CUSTOMER_GROUP');
        $c->newsletter = false;
        $c->optin      = false;
        $c->active     = true;
        if (!$c->add()) throw new Exception('Impossible de créer le client.');
        return (int) $c->id;
    }

    private function createAddress($id_customer, $fullname, $phone, $address)
    {
        $parts = explode(' ', $fullname, 2);
        $a = new Address();
        $a->id_customer  = (int) $id_customer;
        $a->alias        = 'Social Media ' . date('YmdHis');
        $a->firstname    = Tools::substr($parts[0] ?? 'Client', 0, 255);
        $a->lastname     = Tools::substr($parts[1] ?? 'SocialMedia', 0, 255);
        $a->address1     = Tools::substr($address, 0, 128);
        $a->city         = 'Tunis';
        $a->postcode     = '1000';
        $a->phone_mobile = $phone;
        $a->phone        = $phone;
        $a->id_country   = (int) Configuration::get('PS_COUNTRY_DEFAULT');
        $a->id_state     = 0;
        $a->active       = true;
        if (!$a->add()) throw new Exception('Impossible de créer l\'adresse.');
        return (int) $a->id;
    }

    private function createOrderViaValidate($id_customer, $id_address, $id_product)
    {
        $id_status = (int) Configuration::get('SOCIALMEDIAORDER_STATUS_ID');
        if (!$id_status) throw new Exception('Statut de commande introuvable.');

        // Charger le produit pour avoir son prix réel
        $product = new Product((int)$id_product, true, $this->context->language->id);
        if (!Validate::isLoadedObject($product)) throw new Exception('Produit introuvable.');

        // Récupérer le carrier par défaut
        $carriers   = Carrier::getCarriers($this->context->language->id, true, false, false, null, Carrier::ALL_CARRIERS);
        $id_carrier = !empty($carriers) ? (int)$carriers[0]['id_carrier'] : 1;

        // Créer le panier
        $cart = new Cart();
        $cart->id_lang             = (int) $this->context->language->id;
        $cart->id_currency         = (int) $this->context->currency->id;
        $cart->id_customer         = (int) $id_customer;
        $cart->id_address_delivery = (int) $id_address;
        $cart->id_address_invoice  = (int) $id_address;
        $cart->id_carrier          = $id_carrier;
        $cart->id_shop             = (int) $this->context->shop->id;
        $cart->id_shop_group       = (int) $this->context->shop->id_shop_group;
        $cart->secure_key          = md5(uniqid(mt_rand(), true));
        if (!$cart->add()) throw new Exception('Impossible de créer le panier.');

        // Ajouter le produit au panier
        $result = $cart->updateQty(1, (int)$id_product, null, false, 'up', 0, null, true);
        if (!$result) throw new Exception('Impossible d\'ajouter le produit au panier.');
        $cart->update();
        // Forcer le rechargement du panier pour que getProducts() retourne les lignes
        $cart = new Cart((int)$cart->id);

        // Calculer les totaux depuis le panier (montant réel)
        $total_paid = (float) $cart->getOrderTotal(true, Cart::BOTH);
        if ($total_paid <= 0) {
            // Fallback: prix direct du produit
            $total_paid = (float) Product::getPriceStatic((int)$id_product, true);
        }

        // Créer la commande manuellement avec les bons montants
        $o = new Order();
        $o->id_customer         = (int) $id_customer;
        $o->id_address_invoice  = (int) $id_address;
        $o->id_address_delivery = (int) $id_address;
        $o->id_currency         = (int) $cart->id_currency;
        $o->id_lang             = (int) $cart->id_lang;
        $o->id_cart             = (int) $cart->id;
        $o->id_carrier          = (int) $id_carrier;
        $o->id_shop             = (int) $this->context->shop->id;
        $o->id_shop_group       = (int) $this->context->shop->id_shop_group;
        $o->payment             = 'Commande rapide';
        $o->module              = 'socialmediaorder';
        $o->secure_key          = $cart->secure_key;
        $o->total_paid          = $total_paid;
        $o->total_paid_real     = 0;
        $o->total_paid_tax_incl = $total_paid;
        $o->total_paid_tax_excl = (float) $cart->getOrderTotal(false, Cart::BOTH);
        $o->total_products      = (float) $cart->getOrderTotal(false, Cart::ONLY_PRODUCTS);
        $o->total_products_wt   = (float) $cart->getOrderTotal(true,  Cart::ONLY_PRODUCTS);
        $o->total_shipping      = (float) $cart->getOrderTotal(true,  Cart::ONLY_SHIPPING);
        $o->total_shipping_tax_excl = (float) $cart->getOrderTotal(false, Cart::ONLY_SHIPPING);
        $o->total_shipping_tax_incl = (float) $cart->getOrderTotal(true,  Cart::ONLY_SHIPPING);
        $o->total_discounts     = 0;
        $o->total_wrapping      = 0;
        $o->conversion_rate     = 1;
        $o->current_state       = $id_status;
        $o->invoice_number      = 0;
        $o->delivery_number     = 0;
        $o->valid               = 1;
        $o->reference           = Order::generateReference();
        $o->date_add            = date('Y-m-d H:i:s');
        $o->date_upd            = date('Y-m-d H:i:s');

        if (!$o->add()) throw new Exception('Impossible de créer la commande.');

        // Ajouter les produits du panier dans order_detail
        $products = $cart->getProducts(true);
        foreach ($products as $p) {
            $combination_name = '';
            if (!empty($p['attributes_small'])) {
                $combination_name = $p['attributes_small'];
            }

            // Récupérer l'image de couverture du produit (ou de la déclinaison si applicable)
            $id_product_attr = (int) ($p['id_product_attribute'] ?? 0);
            $cover = Product::getCover((int) $p['id_product']);
            if ($id_product_attr) {
                // Chercher l'image liée à la déclinaison en priorité
                $attr_images = Db::getInstance()->executeS(
                    'SELECT pai.id_image FROM `' . _DB_PREFIX_ . 'product_attribute_image` pai
                     WHERE pai.id_product_attribute = ' . $id_product_attr . ' LIMIT 1'
                );
                if (!empty($attr_images)) {
                    $cover = ['id_image' => (int) $attr_images[0]['id_image']];
                }
            }
            $id_image = $cover ? (int) $cover['id_image'] : 0;

            $d = new OrderDetail();
            $d->id_order                = (int) $o->id;
            $d->id_order_invoice        = 0;
            $d->id_warehouse            = 0;
            $d->id_product              = (int) $p['id_product'];
            $d->id_product_attribute    = $id_product_attr;
            $d->product_image_id        = $id_image;
            $d->id_shop                 = (int) $this->context->shop->id;
            $d->product_name            = $p['name'] . (!empty($combination_name) ? ' - ' . $combination_name : '');
            $d->product_quantity        = (int) $p['cart_quantity'];
            $d->product_quantity_in_stock = (int) $p['cart_quantity'];
            $d->product_price           = (float) $p['price'];
            $d->original_product_price  = (float) $p['price'];
            $d->unit_price_tax_incl     = (float) $p['price_wt'];
            $d->unit_price_tax_excl     = (float) $p['price'];
            $d->total_price_tax_incl    = (float) $p['total_wt'];
            $d->total_price_tax_excl    = (float) $p['total'];
            $d->product_reference       = $p['reference'] ?? '';
            $d->product_ean13           = $p['ean13']     ?? '';
            $d->product_isbn            = $p['isbn']      ?? '';
            $d->product_upc             = $p['upc']       ?? '';
            $d->product_weight          = (float) ($p['weight'] ?? 0);
            $d->tax_name                = '';
            $d->tax_rate                = 0;
            $d->tax_computation_method  = 0;
            $d->id_tax_rules_group      = (int) ($p['id_tax_rules_group'] ?? 0);
            $d->ecotax                  = (float) ($p['ecotax'] ?? 0);
            $d->ecotax_tax_rate         = 0;
            $d->discount_quantity_applied = 0;
            $d->download_hash           = '';
            $d->download_nb             = 0;
            $d->download_deadline       = '0000-00-00 00:00:00';
            if (!$d->add()) {
                throw new Exception('Impossible d\'ajouter le produit à la commande.');
            }

            // Décrémenter le stock
            StockAvailable::updateQuantity(
                (int) $p['id_product'],
                (int) ($p['id_product_attribute'] ?? 0),
                -(int) $p['cart_quantity'],
                (int) $this->context->shop->id
            );
        }

        // Historique du statut
        $history = new OrderHistory();
        $history->id_order = (int) $o->id;
        $history->changeIdOrderState($id_status, (int) $o->id);
        $history->addWithemail(true, []);

        return (int) $o->id;
    }
}
