<?php
/**
 * Fichier de configuration du module
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

// Constantes du module
define('SOCIALMEDIAORDER_VERSION', '1.0.0');
define('SOCIALMEDIAORDER_DIR', _PS_MODULE_DIR_ . 'socialmediaorder/');
