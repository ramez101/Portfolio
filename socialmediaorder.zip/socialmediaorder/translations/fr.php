<?php
/**
 * Traductions françaises du module Social Media Order
 */

global $_MODULE;
$_MODULE = [];

$_MODULE['<{socialmediaorder}prestashop>socialmediaorder_'] = 'Module Social Media Order';
$_MODULE['<{socialmediaorder}prestashop>socialmediaorder_commande_via_social_media'] = 'Commande via Social Media';
$_MODULE['<{socialmediaorder}prestashop>socialmediaorder_affiche_un_formulaire_de_commande_rapide'] = 'Affiche un formulaire de commande rapide sur la page produit et crée une commande avec le statut "Commande via Social Media".';
$_MODULE['<{socialmediaorder}prestashop>socialmediaorder_informations'] = 'Informations';
$_MODULE['<{socialmediaorder}prestashop>socialmediaorder_statut_de_commande_utilise'] = 'Statut de commande utilisé :';
$_MODULE['<{socialmediaorder}prestashop>socialmediaorder_les_commandes_recues'] = 'Les commandes reçues via le formulaire produit apparaissent dans';

$_MODULE['<{socialmediaorder}prestashop>product_form_commander_via_social_media'] = 'Commander via Social Media';
$_MODULE['<{socialmediaorder}prestashop>product_form_nom_et_prenom'] = 'Nom et Prénom';
$_MODULE['<{socialmediaorder}prestashop>product_form_numero_de_telephone'] = 'Numéro de téléphone';
$_MODULE['<{socialmediaorder}prestashop>product_form_adresse_de_livraison'] = 'Adresse de livraison';
$_MODULE['<{socialmediaorder}prestashop>product_form_valider_ma_commande'] = 'Valider ma commande';
$_MODULE['<{socialmediaorder}prestashop>product_form_votre_commande_a_bien_ete_enregistree'] = 'Votre commande a bien été enregistrée ! Nous vous contacterons très bientôt.';
$_MODULE['<{socialmediaorder}prestashop>product_form_en_validant'] = 'En validant, notre équipe vous contactera pour confirmer votre commande.';

$_MODULE['<{socialmediaorder}prestashop>submit_nom_et_prenom_est_obligatoire'] = 'Nom et Prénom est obligatoire.';
$_MODULE['<{socialmediaorder}prestashop>submit_numero_de_telephone_est_obligatoire'] = 'Numéro de téléphone est obligatoire.';
$_MODULE['<{socialmediaorder}prestashop>submit_adresse_est_obligatoire'] = 'Adresse est obligatoire.';
$_MODULE['<{socialmediaorder}prestashop>submit_produit_invalide'] = 'Produit invalide.';
$_MODULE['<{socialmediaorder}prestashop>submit_erreur_lors_de_la_creation'] = 'Erreur lors de la création de la commande.';
